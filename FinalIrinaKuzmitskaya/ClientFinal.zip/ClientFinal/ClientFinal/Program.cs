﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        string baseUrl = "https://localhost:7226/swagger"; // Base URL of your API
        string insertEndpoint = "/api/projet/inserer";
        string getEndpoint = "/api/projet/obtenir/";

        HttpClient client = new HttpClient();
        client.BaseAddress = new Uri(baseUrl);
        client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        try
        {
            Console.Write("Enter CodeProjet: ");
            if (!int.TryParse(Console.ReadLine(), out int codeProjet))
            {
                Console.WriteLine("Invalid input for CodeProjet. Please enter a valid integer.");
                return;
            }

            Console.Write("Enter Description: ");
            string description = Console.ReadLine();

            string json = $"{{ \"CodeProjet\": {codeProjet}, \"Description\": \"{description}\" }}";

            HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage responseInsert = await client.PostAsync(insertEndpoint, content);

            if (responseInsert.IsSuccessStatusCode)
            {
                string result = await responseInsert.Content.ReadAsStringAsync();
                Console.WriteLine(result);
            }
            else
            {
                Console.WriteLine($"Error inserting project: {responseInsert.StatusCode}");
            }

            HttpResponseMessage responseGet = await client.GetAsync(getEndpoint + codeProjet);

            if (responseGet.IsSuccessStatusCode)
            {
                string result = await responseGet.Content.ReadAsStringAsync();
                Console.WriteLine(result);
            }
            else
            {
                Console.WriteLine($"Error getting project: {responseGet.StatusCode}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }

        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}
