﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;

namespace GestionProjetService.Controllers
{
    [Route("api/projet")]
    [ApiController]
    public class ProjetController : ControllerBase
    {
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyProjectDB;Integrated Security=True";


        [HttpPost]
        [Route("inserer")]
        public IActionResult InsererProjet([FromBody] Projet projet)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO project (code_projet, description) VALUES (@code_projet, @description)";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@code_projet", projet.CodeProjet);
                        cmd.Parameters.AddWithValue("@description", projet.Description);
                        cmd.ExecuteNonQuery();
                    }
                }
                return Ok("Projet inséré avec succès!");
            }
            catch (Exception ex)
            {
                return BadRequest($"Erreur : {ex.Message}");
            }
        }

        [HttpGet]
        [Route("obtenir/{code_projet}")]
        public IActionResult ObtenirProjet(int code_projet)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM project WHERE code_projet = @code_projet";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@code_projet", code_projet);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Projet projet = new Projet
                                {
                                    CodeProjet = Convert.ToInt32(reader["code_projet"]),
                                    Description = reader["description"].ToString()
                                };
                                return Ok(projet);
                            }
                        }
                    }
                }
                return NotFound("Projet non trouvé");
            }
            catch (Exception ex)
            {
                return BadRequest($"Erreur : {ex.Message}");
            }
        }
    }

    public class Projet
    {
        public int CodeProjet { get; set; }
        public string Description { get; set; }
    }
}
