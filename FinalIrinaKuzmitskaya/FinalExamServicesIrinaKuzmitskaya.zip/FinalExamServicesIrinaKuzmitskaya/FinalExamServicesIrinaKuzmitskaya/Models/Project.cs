﻿namespace FinalExamServicesIrinaKuzmitskaya.Models
{
    public class Project
    {
        public int Id { get; set; }         
        public string Code_projet { get; set; }   
        public string Description { get; set; }  
    }

}
